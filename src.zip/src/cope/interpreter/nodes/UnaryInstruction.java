package cope.interpreter.nodes;

public interface UnaryInstruction
{
	public float evaluate(double arg);
	public String getString();
}
